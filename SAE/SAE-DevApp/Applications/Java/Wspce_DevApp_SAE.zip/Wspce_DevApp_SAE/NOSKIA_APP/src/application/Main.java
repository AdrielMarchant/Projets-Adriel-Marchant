package application;
	
import application.controller.NoskiaMainFrame;


public class Main {
	/**
	 * Lance l'application sur la trame principale (via le controlleur NoskiaMainFrame)
	 * 
	 * @param args argument du main 
	 */
	public static void main(String[] args) {
		NoskiaMainFrame.runApp();
	}
}
