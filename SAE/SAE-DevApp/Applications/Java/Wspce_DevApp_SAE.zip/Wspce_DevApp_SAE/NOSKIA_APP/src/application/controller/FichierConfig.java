package application.controller;


import java.util.Map;

import application.tools.StageManagement;
import application.view.FichierConfigController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.orm.accessAppPython;



public class FichierConfig {
	private FichierConfigController fcc;
	private Stage primaryStage;
	private NoskiaMainFrame nfm;
	
	
	private accessAppPython app;

	/**
	 * Contructeur paramétrique 
	 * 
	 * Génére la fenêtre via le fichier FXML, initialise son contexte et sa configuration
	 * 
	 * Intiliase l'attribut nfm (NoskiaMainFrame)
	 * 
	 * @param _parentStage la fenêtre parent qui ouvre celle ci
	 * @param _nfm le controller de la fenêtre principale.
	 */
	public FichierConfig(Stage _parentStage, NoskiaMainFrame _nfm) {
		try {
			this.app = new accessAppPython();
			
			FXMLLoader loader = new FXMLLoader(FichierConfigController.class.getResource("FichierConfigPane.fxml"));
			AnchorPane root = loader.load();

			Scene scene = new Scene(root);
			scene.getStylesheets().add(FichierConfigController.class.getResource("NoskiaMainFramePane.css").toExternalForm());

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Gestion du fichier de configuration");
			this.primaryStage.setResizable(false);

			this.nfm = _nfm;
			
			this.fcc = loader.getController();
			this.fcc.initContext(this.primaryStage, this);
			
			this.fcc.loadConfiguration(this.doGetWantedData(), this.doGetSeuils(), this.doGetFrequence());
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Appelle la fonction qui va afficher la fenêtre, est appellé par la page parent (page d'acceuil)
	 */
	public void doConfigurationFichierConfig() {
		this.fcc.displayDialog();
	}
	
	/**
	 * Appelle la fonction qui récupère les informations envoyé par la classe de gestion de la vue 
	 * et les enregistre dans le fichier config.ini de la partie model.
	 * 
	 * @param wantedData les données de la partie  "donnée récupérer" du formulaire (données que l'on veut afficher)
	 * @param seuils les données de la partie "seuils" du formulaire
	 * @param freq la fréquence à laquelle on récupère les données
	 * 
	 */
	public void doSaveConfiguration(Map<String, Boolean> wantedData, Map<String, String> seuils, String freq) {
		this.app.saveConfiguration(wantedData, seuils, freq);
		this.nfm.doActualiserAffichageParametre();
	}
	
	/**
	 * Appelle la fonction qui récupère les valeurs de la partie "data" du fichier config.ini
	 * 
	 * Utilisé pour rechargé le paramétrage précédent des valeurs
	 * 
	 * @return HashMap la map des valeurs
	 */
	public Map<String, Boolean> doGetWantedData() {
		return this.app.getWantedData();
	}
	
	/**
	 * Appelle la fonction qui récupère les valeurs de la partie "seuils" du fichier config.ini
	 * 
	 * Utilisé pour rechargé le paramétrage précédent des valeurs
	 * 
	 * @return HashMap la map des valeurs
	 */
	public Map<String, String> doGetSeuils() {
		return this.app.getSeuils();
	}
	
	/**
	 * Appelle la fonction qui récupère la de la partie "fréquences" du fichier config.ini
	 * 
	 * Utilisé pour rechagé le paramétrage précédent des valeurs
	 * 
	 * @return String la valeur en String (à convertir en float)
	 */
	public String doGetFrequence() {
		return this.app.getFrequence();
	}
	
	
		
	
	
	
}
