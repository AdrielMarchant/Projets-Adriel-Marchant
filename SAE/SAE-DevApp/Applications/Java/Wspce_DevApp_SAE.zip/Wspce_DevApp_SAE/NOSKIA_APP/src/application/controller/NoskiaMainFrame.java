package application.controller;


import java.util.List;
import java.util.Map;

import javax.json.JsonObject;

import application.view.NoskiaMainFrameController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.orm.accessAppPython;

public class NoskiaMainFrame extends Application {
	private Stage primaryStage;
	private NoskiaMainFrameController nmfc;
	
	private accessAppPython app;
	
	private FichierConfig fc;
	
	private Process processPython;

	/**
	 * Appelé au lancement de l'application.
	 * 
	 * Permet de générer la fenêtre principale de l'application via le fichier NoskiaMainFramePane.fxml 
	 * et lance l'initialisation de son texte via sa classe de gestion de la vue 
	 * 
	 * Initialise les attributes fc (FichierConfig) et app (accessPythonApp) et installe la bibliothèque paho-mqtt nécessaire au fonctionnement de l'application python.
	 * 
	 * @param primaryStage la fenêtre principale de cette page
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		this.primaryStage = primaryStage;
		try {
			Runtime.getRuntime().exec("pip install paho-mqtt");
			this.fc = new FichierConfig(this.primaryStage, this);
			this.app  = new accessAppPython();
		
			FXMLLoader loader = new FXMLLoader(
					NoskiaMainFrameController.class.getResource("NoskiaMainFramePane.fxml"));
			
			BorderPane root = loader.load();
	
			Scene scene = new Scene(root, root.getPrefWidth()+20, root.getPrefHeight()+10);
			scene.getStylesheets().add(NoskiaMainFrameController.class.getResource("NoskiaMainFramePane.css").toExternalForm());
	
			
			this.nmfc = loader.getController();
			
			primaryStage.setScene(scene);
			primaryStage.setTitle("Noskia Management");
			this.primaryStage.setResizable(false);
			
			this.nmfc.initContext(primaryStage, this);
			
			
			
			this.nmfc.displayDialog();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * Ouvre la page d'acceuil
	 */
	public static void runApp() {
		Application.launch();
	}

	/**
	 * Créer une page de configuration et lance la fonction qui va lancé son affichage
	 */
	public void startConfiguration() {
		this.fc.doConfigurationFichierConfig();
	}
	
	/**
	 * Récupère les données sélectionnées lors de la configuration
	 * 
	 * @return une map avec pour clé le nom de la valeur et en valeur true si elle est sélectionnée et false sinon
	 */
	public Map<String, Boolean> getSelectedData(){
		return this.fc.doGetWantedData();
	}
	
	/**
	 * Fait appel à la méthode qui actualise l'affichage du contenu
	 */
	public void doActualiserAffichageParametre() {
		this.nmfc.actualiserAffichageParametre();
	}
	
	/**
	 * Appelle la méthode qui lance le timer qui va actualiser le graphique
	 */
	public void doStartTimer() {
		this.nmfc.startTimer();
	}
	
	/**
	 * Fait appel à la méthode qui lance l'application python
	 */
	public void doStartPythonApp() {	
		this.processPython = this.app.startPythonApp();
	}
	
	/**
	 * Fait appel à la méthode qui stop l'application python si le processus qui exécute le programme python existe
	 */
	public void doStopPythonApp() {
		if(this.processPython != null) {
			this.app.stopPythonApp();
		}
		
	}
	
	/**
	 * Appelle la fonction qui permet de modifier le champ "device_choisie" de la partie "device" du fichier .ini en enregistrant la salle choisi dans le menu déroulant
	 * 
	 * @param salle la salle du menu déroulant
	 */
	public void doSetDeviceChoisi(String salle) {
		this.app.setDeviceChoisi(salle);
	}
	
	

	/**
	 * Permet d'appeler la fonction qui récupère toute les données présente dans le fichier de données d'une salle
	 * 
	 * @param salle la salle voulu
	 * @return une Liste de jsonObject des données
	 */
	public List<JsonObject> doGetAllData(String salle) {
		return this.app.getData(this.app.getDeviceNameBySalle(salle));
	}
	
	/**
	 * Permet d'appeler la fonction qui récupère les nouvelle données réçu dans le fichier de données d'une salle.
	 * 
	 * 
	 * @param salle la salle voulu
	 * @return une Liste de jsonObject des nouvelles données. S'il n'y a pas de nouvelles données, la liste est vide.
	 */
	public List<JsonObject> doGetNewData(String salle) {
		return this.app.getNewData(this.app.getDeviceNameBySalle(salle));
	}
	
	/**
	 * Retourne la fréquence en chaine de caractère présente dans le fichier de configuration.
	 * 
	 * @return la fréquence en string
	 */
	public String doGetFrequence() {
		return this.app.getFrequence();
	}
	
}
