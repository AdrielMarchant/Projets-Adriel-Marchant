package application.tools;

import javafx.stage.Stage;

public class StageManagement {
	
	/**
	 * Permet de center la fenêtre ouverte par rapport à la fenêtre appelante (la fenêtre parent)
	 * 
	 * @param parent la fenêtre parent 
	 * @param primary la fenêtre que l'on veut centrer
	 */
	public static void manageCenteringStage(Stage parent, Stage primary) {

		// Calculate the center position of the parent Stage
		double centerXPosition = parent.getX() + parent.getWidth() / 2d;
		double centerYPosition = parent.getY() + parent.getHeight() / 2d;

		// Hide the pop-up stage before it is shown and becomes relocated
		primary.setOnShowing(ev -> primary.hide());

		// Relocate the pop-up Stage
		primary.setOnShown(ev -> {
			primary.setX(centerXPosition - primary.getWidth() / 2d);
			primary.setY(centerYPosition - primary.getHeight() / 2d);
			primary.show();
		});
	}
}
