package application.tools;

import java.util.List;
import java.util.Map;
import java.util.TimerTask;

import javax.json.JsonObject;

import application.view.NoskiaMainFrameController;
import javafx.application.Platform;
import model.orm.accessAppPython;

public class TaskBackground extends TimerTask{
	private NoskiaMainFrameController nmfc;
	private accessAppPython app;
	
	private String dataVoulu;
	private String seuilMin = null;
	private String seuilMax = null;
	
	private int nbAppel = 0;
	
	/**
	 * Constructeur paramétrique
	 * 
	 * @param _nmfc le controller qui va créer des timer
	 */
	public TaskBackground(NoskiaMainFrameController _nmfc) {
		this.nmfc = _nmfc;
		this.app = new accessAppPython();
		
	}

	/**
	 * Permet de mettre à jour les données du graphique et les alertes sur un thread différent du principale.
	 * Pour cela, récupère les seuils en fonction de la donnée voulu. Si le nombre d'appel de la fonction est 0, alors on charge les données précédentes dans le graphe.
	 * 
	 */
	@Override
	public void run() {
		Map<String, String> seuils = this.app.getSeuils();

		switch(this.dataVoulu) {
		case "temperature":
			this.seuilMin = seuils.get("temp-1");
			this.seuilMax = seuils.get("temp-2");
			break;
		case "humidity":
			this.seuilMin = seuils.get("humidity-1");
			this.seuilMax = seuils.get("humidity-2");
			break;
		default:
			this.seuilMax = seuils.get(this.dataVoulu);
		}
		
		if(this.seuilMin == null) {
			this.seuilMin = "0";
		}
		
		//Seuil max supérieur au nombre de chiffre maximum des seuils (pour ne jamais les dépassés)
		if(this.seuilMax == null) {
			this.seuilMax = "10000";
		}
		
	    List<JsonObject> nouv;
	    if(this.nbAppel == 0) {
	    	nouv = this.nmfc.getAllData();
	    } else {
	    	nouv = this.nmfc.getNewData();
	    }
	    
	    System.out.println("data : "+nouv);
	    System.out.println("alarmes : "+this.app.getNewAlarm());
	    
	    if(nouv.size()>0) {
	    	for(JsonObject JO : nouv) {
	    		String name = JO.getString("date");
	    		try {
		    		int valeur = JO.getInt(this.dataVoulu);
		    		
		    		Platform.runLater(new Runnable() {
		    			@Override
		    			public void run() {
		    				TaskBackground.this.nmfc.misteAJourBarChart(name, valeur, Integer.parseInt(TaskBackground.this.seuilMin), Integer.parseInt(TaskBackground.this.seuilMax));
		    				TaskBackground.this.nmfc.miseAJourListViewAlarmes(TaskBackground.this.app.getNewAlarm());
		    			}
		    		});
	    		} catch (Exception e) {
	    			//Récupérer les exceptions et les ignors
	    			//Permet de pouvoir rajouter l'affichage de nouvelle donnée en cours de fonctionnement
	    		}
	    		
	    	}	
	    }
	    System.out.println(this.nbAppel);
	    this.nbAppel +=1;
	}
	
	/**
	 * Enregistre la donnée que l'on veut afficher sur le graphe.
	 * 
	 * @param _dataVoulu la donnée voulue
	 */
	public void setDataVoulu(String _dataVoulu) {
		this.dataVoulu = _dataVoulu;
	}
}
