package application.view;


import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import application.controller.FichierConfig;
import application.tools.AlertUtilities;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class FichierConfigController implements Initializable{
	private Stage primaryStage;
	private FichierConfig fc;
	
	/**
	 * Initialise le contexte de la page (fenêtre principale, controller) et lance la configuration de la page.
	 * 
	 * @param _containingStage la fenêtre principale
	 * @param _fc le controller de la fenêtre principale
	 *  
	 */
	public void initContext(Stage _containingStage,FichierConfig _fc ) {
		this.primaryStage = _containingStage;
		this.fc =_fc;
		this.configure();
	}
	
	/** 
	 * Configure la page (listener à la fermeture de la page, lance les vérifications de rentré dans les textfields, affiche les valeurs des slider)
	 * 
	 * Lance l'affichage des valeurs du slider et la vérification de la valeur des textfields
	 */
	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
		this.validateInputType();
		this.affichageSliderValue();
		
	}
	
	/**
	 * Permet à n'autoriser uniquement les entiers positifs sur les textfield de la frequence, le co2 et l'activite.
	 * Limite le nombre de caractères max que l'on peut rentré dans les textfields
	 */
	private void validateInputType() {
		// Accepte uniquement les chiffres pour la frequence et limite le nombre de caractères à 4.
		TextField textfield1= this.fequence;
		textfield1.textProperty().addListener(new ChangeListener<String>() {
		    @Override
		    public void changed(ObservableValue<? extends String> observable, String oldValue, 
		        String newValue) {
		        if (!newValue.matches("\\d*")) {
		        	newValue = "";
		        	textfield1.setText(newValue);
		        }
		        if (textfield1.getText().length() > 4) {
	                String s = textfield1.getText().substring(0, 4);
	                textfield1.setText(s);
	            }
		    }
		});
		
		// Accepte uniquement les chiffres pour le co2 et limite le nombre de caractères à 4.
		TextField textfield2= this.s_co2Max;
		textfield2.textProperty().addListener(new ChangeListener<String>() {
		    @Override
		    public void changed(ObservableValue<? extends String> observable, String oldValue, 
		        String newValue) {
		        if (!newValue.matches("\\d*")) {
		        	newValue = "";
		        	textfield2.setText(newValue);
		        }
		        if (textfield2.getText().length() > 4) {
	                String s = textfield2.getText().substring(0, 4);
	                textfield2.setText(s);
	            }
		    }
		});
		
		// Accepte uniquement les chiffres pour l'activité et limite le nombre de caractères à 4.
		TextField textfield3= this.s_actMax;
		textfield3.textProperty().addListener(new ChangeListener<String>() {
		    @Override
		    public void changed(ObservableValue<? extends String> observable, String oldValue, 
		        String newValue) {
		        if (!newValue.matches("\\d*")) {
		        	newValue = "";
		        	textfield3.setText(newValue);
		        }
		        if (textfield3.getText().length() > 4) {
	                String s = textfield3.getText().substring(0, 4);
	                textfield3.setText(s);
	            }
		    }
		});
	}
	
	/**
	 * Permet de pré-remplire le formulaire avec les précédentes valeurs du fichier de configuration.
	 * 
	 * @param wantedData les données de la partie  "donnée récupérer" du formulaire (données que l'on veut afficher)
	 * @param seuils les données de la partie "seuils" du formulaire
	 * @param freq la fréquence à laquelle on récupère les données
	 */
	public void loadConfiguration(Map<String, Boolean> wantedData, Map<String, String> seuils, String freq) {
		for(Entry<String, Boolean> e: wantedData.entrySet()) {
			if(e.getKey().equals("co2") && e.getValue() == true) {
				this.rd_co2.setSelected(true);
			}
			if(e.getKey().equals("temperature") && e.getValue() == true) {
				this.rd_temperature.setSelected(true);
			}
			if(e.getKey().equals("humidity") && e.getValue() == true) {
				this.rd_humidite.setSelected(true);
			}
			if(e.getKey().equals("activity") && e.getValue() == true) {
				this.rd_activite.setSelected(true);
			}
			if(e.getKey().equals("illumination") && e.getValue() == true) {
				this.rd_illumination.setSelected(true);
			}
			if(e.getKey().equals("infrared") && e.getValue() == true) {
				this.rd_infrared.setSelected(true);
			}
			if(e.getKey().equals("infrared_and_visible") && e.getValue() == true) {
				this.rd_infraredandvisible.setSelected(true);
			}
			if(e.getKey().equals("pressure") && e.getValue() == true) {
				this.rd_pression.setSelected(true);
			}
			if(e.getKey().equals("tvoc") && e.getValue() == true) {
				this.rd_tvoc.setSelected(true);
			}
		}
		
		
		for(Entry<String, String> e: seuils.entrySet()) {
			if(e.getKey().equals("activity")) {
				this.s_actMax.setText(e.getValue());
			}
			if(e.getKey().equals("co2")) {
				this.s_co2Max.setText(e.getValue());
			}
			if(e.getKey().equals("temp-1")) {
				this.value_slider_tempMin.setText(e.getValue()+" °C");
				this.slider_tempMin.setValue(Float.valueOf(e.getValue()));
			}
			if(e.getKey().equals("temp-2")) {
				this.value_slider_tempMax.setText(e.getValue()+" °C");
				this.slider_tempMax.setValue(Float.valueOf(e.getValue()));
			}
			if(e.getKey().equals("humidity-1")) {
				this.value_slider_humMin.setText(e.getValue()+" %");
				this.slider_humMin.setValue(Float.valueOf(e.getValue()));
			}
			if(e.getKey().equals("humidity-2")) {
				this.value_slider_humMax.setText(e.getValue()+" %");
				this.slider_humMax.setValue(Float.valueOf(e.getValue()));
			}
		}
		
		
		this.fequence.setText(freq);
	}
	
	/**
	 * S'active à la fermeture de la fenêtre, lance la fonction doQuit et consume l'évènement.
	 */
	private Object closeWindow(WindowEvent e) {
		this.doQuit();
		e.consume();
		return null;
	}
	
	/**
	 * Affiche la page et attend une intéraction avec.
	 */
	public void displayDialog() {
		this.primaryStage.showAndWait();
	}

	
	@FXML 
	private TextField s_co2Max;
	@FXML 
	private TextField s_actMax;
	@FXML
	private TextField fequence;
	
	@FXML
	private Label value_slider_tempMin;
	@FXML
	private Label value_slider_tempMax;
	@FXML
	private Label value_slider_humMin;
	@FXML
	private Label value_slider_humMax;
	
	@FXML
	private Slider slider_tempMin;
	@FXML
	private Slider slider_tempMax;
	@FXML
	private Slider slider_humMin;
	@FXML
	private Slider slider_humMax;
	
	@FXML
	private RadioButton rd_co2;
	@FXML
	private RadioButton rd_temperature;
	@FXML
	private RadioButton rd_activite;
	@FXML
	private RadioButton rd_humidite;
	@FXML
	private RadioButton rd_tvoc;
	@FXML
	private RadioButton rd_pression;
	@FXML
	private RadioButton rd_infrared;
	@FXML
	private RadioButton rd_infraredandvisible;
	@FXML
	private RadioButton rd_illumination;
	

	
	
	
	/**
	 * Ferme la page
	 */
	@FXML
	private void doQuit() {
		this.primaryStage.close();
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	}
	
	
	
	/**
	 * S'active à la pression du bouton valider.
	 * 
	 * Permet d'enregistrer les données dans 2 HashMap (une pour les seuils et l'autre pour les données voulues)
	 * et une chaine de caractère (la fréquence).
	 * 
	 * Envoie ces informations au controller pour qu'il intéragisse avec la partie model.
	 * 
	 */
	@FXML
	private void saveConfiguration() {
		AlertUtilities.showAlert(primaryStage, "Alerte", "Modifications sauvegardées", null, null);
		Map<String, Boolean> selectedData = new HashMap<String, Boolean>();
		selectedData.put("co2", this.rd_co2.isSelected());
		selectedData.put("temperature", this.rd_temperature.isSelected());
		selectedData.put("humidity", this.rd_humidite.isSelected());
		selectedData.put("tvoc", this.rd_tvoc.isSelected());
		selectedData.put("pressure", this.rd_pression.isSelected());
		selectedData.put("illumination", this.rd_illumination.isSelected());
		selectedData.put("activity", this.rd_activite.isSelected());
		selectedData.put("infrared", this.rd_infrared.isSelected());
		selectedData.put("infrared_and_visible", this.rd_infraredandvisible.isSelected());
		
		Map<String, String> seuils = new HashMap<String, String>();
		
		
		seuils.put("co2", this.s_co2Max.getText());
		seuils.put("temp-1", ""+Math.round(this.slider_tempMin.getValue()));
		seuils.put("temp-2", ""+Math.round(this.slider_tempMax.getValue()));
		seuils.put("humidity-1", ""+Math.round(this.slider_humMin.getValue()));
		seuils.put("humidity-2", ""+Math.round(this.slider_humMax.getValue()));
		seuils.put("activity", this.s_actMax.getText());
		
		this.fc.doSaveConfiguration(selectedData, seuils, this.fequence.getText());
		
		this.doQuit();
	}
	
	
	/**
	 * S'active lorsque l'on clique sur un des sliders. 
	 * 
	 * Permet d'afficher la valeur du slider.
	 * 
	 */
	@FXML
	private void affichageSliderValue() {
		this.value_slider_tempMin.setText(Math.round(this.slider_tempMin.getValue())+" °C");
		this.value_slider_tempMax.setText(Math.round(this.slider_tempMax.getValue())+" °C");
		this.value_slider_humMin.setText(Math.round(this.slider_humMin.getValue())+" %");
		this.value_slider_humMax.setText(Math.round(this.slider_humMax.getValue())+" %");
	}
	
	
}
