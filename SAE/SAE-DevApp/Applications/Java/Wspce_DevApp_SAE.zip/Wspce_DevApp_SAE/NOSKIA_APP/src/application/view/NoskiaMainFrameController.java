package application.view;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Timer;

import javax.json.JsonObject;

import application.controller.NoskiaMainFrame;
import application.tools.AlertUtilities;
import application.tools.TaskBackground;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class NoskiaMainFrameController implements Initializable {
	private Stage primaryStage;
	private NoskiaMainFrame nmf;

	
	private TaskBackground tb;
	private Timer timer;
	
	private Series<String, Number> dataSerie;
	private Boolean isDataChoisi = false;
	
	
	
	/**
	 * Initialise le contexte de la page (la fenêtre principale de la page, le controller) et lance la configuration de la page.
	 * 
	 * @param _containingStage la fenêtre princiaple
	 * @param _NoskiaMainFrame le controller de la fenêtre principale
	 */
	public void initContext(Stage _containingStage, NoskiaMainFrame _NoskiaMainFrame) {
		this.primaryStage = _containingStage;
		this.nmf = _NoskiaMainFrame;
		this.configure();
		//System.out.println(this.nmf.doGetData());
	}
	
	
	
	/**
	 * Configure la page (ajout d'une fonction à l'évènement de fermeture de la page).
	 * Retire les animations des graphes (qui causé des problèmes avec le nom des données sur l'axe X)
	 * 
	 * Lance la gestion du menu
	 */
	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
		this.barchart.setAnimated(false);
		this.headerManagement();
	}
	
	/**
	 * Affichage le contenu de la page
	 * 
	 * Initialise la séries du données du graphique et paramètre le graphique (retire la légende)
	 */
	public void displayDialog() {
		this.primaryStage.show();

		this.dataSerie = new XYChart.Series<String, Number>();

		this.barchart.getData().add(this.dataSerie);
		this.barchart.setLegendVisible(false);
	}
	
	/**
	 * Cette fonction gère l'utilisation des thread et des taskbackground en fonction de quand on chosi une donnée.
	 * Si une taskbackground n'existe pas encore, on annule le timer actuel et on stop l'application python
	 * Une fois cela fais, on relance l'application python puis on créer donc une taskBackground puis lance un timer qui s'actualisera toutes les n secondes (n=fréquence choisi)
	 * 
	 */
	public void startTimer() {
		if (this.tb != null) {
			this.tb.cancel();
			this.nmf.doStopPythonApp();
		} 
		this.nmf.doStartPythonApp();
		this.tb = new TaskBackground(this);
		this.tb.setDataVoulu(this.dataChoisi);
		this.timer = new Timer();
		this.timer.schedule(tb, 0, Long.parseLong(this.nmf.doGetFrequence()+"000"));
	}
	
	/**
	 * Lancé par la fermeture de la page.
	 * 
	 * Lance la fonction de fermeture et consumme l'évènement
	 */
	private Object closeWindow(WindowEvent e) {
		this.doQuit();
		e.consume();
		return null;
	}

	
	@FXML
	private SplitMenuButton LD_salle;
	@FXML
	private MenuItem B201;
	@FXML
	private MenuItem B202;
	@FXML
	private MenuItem B203;
	@FXML
	private MenuItem B110;
	@FXML
	private MenuItem B111;
	@FXML
	public String salleChoisi;
	
	@FXML
	private Label title;
	
	@FXML
	private Label gridName ;
	@FXML
	private Button b_co2;
	@FXML
	private Button b_temperature;
	@FXML
	private Button b_humidity;
	@FXML
	private Button b_pressure;
	@FXML
	private Button b_illumination;
	@FXML
	private Button b_infrared;
	@FXML
	private Button b_infrared_and_visible;
	@FXML
	private Button b_tvoc;
	@FXML
	private Button b_activity;
	@FXML
	private String dataChoisi;
	
	
	@FXML
	private Button b_configurer;
	
	@FXML
	private Pane alertPane;
	@FXML
	private ListView<String> LV_alertes;
	
	@FXML
	private Pane dataPane;
	@FXML
	private Label derniereData;
	
	@FXML
	private BarChart<String, Number> barchart;
	@FXML
	private Label barchartName;
	/*
	@FXML
	private Pane containerBarChart;*/
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {	
	}
	
	/**
	 * Affiche un popup de demande de confirmation pour quitter la page
	 * 
	 * Si oui, la page et quitté, sinon elle reste ouverte. A la fermeture, on termine l'exécution du timer et de l'application python.
	 */
	@FXML
	private void doQuit() {
		if (AlertUtilities.confirmYesCancel(this.primaryStage, "Quitter Appli Principale",
				"Etes vous sur de vouloir quitter l'appli ?", null, AlertType.CONFIRMATION)) {
			this.primaryStage.close();
			if(this.tb != null) {
				this.timer.cancel();
			}
			this.nmf.doStopPythonApp();
		}
	}
	
	/**
	 * S'active à la pression du bouton du bouton "configuration"
	 * 
	 * Permet de la lancer l'ouverture de la page de configuration
	 */
	@FXML
	private void doConfiguration() {
		this.nmf.startConfiguration();
	}
	

	/**
	 * Permet d'actualiser la liste déroulante, le titre de la page, le choix des données en fonction du choix de la salle et la configuration du fichier .ini (partie device choisi)
	 * 
	 * Retire le contenu de la page tant qu'un choix de la liste déroulant n'est pas sélectionné. Et lance l'affichage du contenu lorsqu'une salle est selectionnée
	 * 
	 * 
	 * Lance la gestion du contenu.
	 */
	private void headerManagement() {
		unseeContent();
		this.B201.setOnAction((e)-> {
		    this.LD_salle.setText(this.B201.getText());
		    this.title.setText("Données de la salle "+this.B201.getText());
		    this.isDataChoisi = false;
		    this.nmf.doSetDeviceChoisi(this.B201.getText()); 
		    this.salleChoisi = this.B201.getText();
		    seeContent();
		});
		this.B202.setOnAction((e)-> {
		    this.LD_salle.setText(this.B202.getText());
		    this.title.setText("Données de la salle "+this.B202.getText());
		    this.isDataChoisi = false;
		    this.nmf.doSetDeviceChoisi(this.B202.getText()); 
		    this.salleChoisi = this.B202.getText();
		    seeContent();
		});
		this.B203.setOnAction((e)-> {
		    this.LD_salle.setText(this.B203.getText());
		    this.title.setText("Données de la salle "+this.B203.getText());
		    this.isDataChoisi = false;
		    this.nmf.doSetDeviceChoisi(this.B203.getText()); 
		    this.salleChoisi = this.B203.getText();
		    seeContent();
		});
		this.B110.setOnAction((e)-> {
		    this.LD_salle.setText(this.B110.getText());
		    this.title.setText("Données de la salle "+this.B110.getText());
		    this.isDataChoisi = false;
		    this.nmf.doSetDeviceChoisi(this.B110.getText());
		    this.salleChoisi = this.B110.getText();
		    seeContent();
		});
		this.B111.setOnAction((e)-> {
		    this.LD_salle.setText(this.B111.getText());
		    this.title.setText("Données de la salle "+this.B111.getText());
		    this.isDataChoisi = false;
		    this.nmf.doSetDeviceChoisi(this.B111.getText()); 
		    this.salleChoisi = this.B111.getText();
		    seeContent();
		});
		contentManagement();
	}
	
	/**
	 * Gestion du contenu : A la pression d'un des boutons de donnée lance la mise à jour du contenu et lance l'affichage progressif des éléments de la page
	 */
	private void contentManagement() {
		this.b_activity.setOnAction((e) -> {
			this.updateContent(this.b_activity.getText(), true, "activity");
			seeContent();
		});
		this.b_co2.setOnAction((e) -> {
			this.updateContent(this.b_co2.getText(), true, "co2");
			seeContent();
		});
		this.b_humidity.setOnAction((e) -> {
			this.updateContent(this.b_humidity.getText(), true, "humidity");
			seeContent();
		});
		this.b_illumination.setOnAction((e) -> {
			this.updateContent(this.b_illumination.getText(), true, "illumination");
			seeContent();
		});
		this.b_infrared.setOnAction((e) -> {
			this.updateContent(this.b_infrared.getText(), true, "infrared");
			seeContent();
		});
		this.b_infrared_and_visible.setOnAction((e) -> {
			this.updateContent(this.b_infrared_and_visible.getText(), true, "infrared_and_visible");
			seeContent();
		});
		this.b_pressure.setOnAction((e) -> {
			this.updateContent(this.b_pressure.getText(), true, "pressure");
			seeContent();
		});
		this.b_temperature.setOnAction((e) -> {
			this.updateContent(this.b_temperature.getText(), true, "temperature");
			seeContent();
		});
		this.b_tvoc.setOnAction((e) -> {
			this.updateContent(this.b_tvoc.getText(), true, "tvoc");
			seeContent();
		});
	}
	
	/**
	 * Actualise l'affichage du contenu de la page en affichant le nom du graphe, enregistre si une donnée est choisi et son nom.
	 * Lance un thread qui s'occupera de l'affichage du graphe.
	 * 
	 * @param _barchartName le nom du graphe
	 * @param _isDataChoisi si la donnée est choisi
	 * @param _dataChoisi le nom de la donnée choisi
	 */
	private void updateContent(String _barchartName, Boolean _isDataChoisi, String _dataChoisi) {
		//Nom du barchart
		this.barchartName.setText(_barchartName);
		//Retire les anciennes données du barchart
		this.dataSerie.getData().clear();
		//Identique qu'une donnée est choisi
		this.isDataChoisi = _isDataChoisi;
		//Enregistre la nom de la donnée choisi
		this.dataChoisi = _dataChoisi;
		//On lance un timer qui s'occupera du graphe affiche
		this.startTimer();
	}

	/**
	 * Retire le contenu de la page d'accueil
	 */
	private void unseeContent() {

		this.gridName.setVisible(false);
		this.b_activity.setVisible(false);
		this.b_co2.setVisible(false);
		this.b_illumination.setVisible(false);
		this.b_infrared.setVisible(false);
		this.b_infrared_and_visible.setVisible(false);
		this.b_pressure.setVisible(false);
		this.b_tvoc.setVisible(false);
		this.b_humidity.setVisible(false);
		this.b_temperature.setVisible(false);
		
		this.barchart.setVisible(false);
		this.barchartName.setVisible(false);
		this.dataPane.setVisible(false);
		
		this.alertPane.setVisible(false);
		
		this.b_configurer.setVisible(false);
		
	}
	
	/**
	 * Gère l'affichage progressif des éléments de la page d'acceuil.
	 * 
	 * Affiche les boutons et alertes lorsqu'une salle est selectionnée.
	 * Affiche le graphe et l'information sur les données lorsqu'un type de donnée est choisi.
	 */
	private void seeContent() {
		Map<String, Boolean> selectedData = this.nmf.getSelectedData();
		this.gridName.setVisible(true);
		if (selectedData.get("co2") == true) {
			this.b_co2.setVisible(true);
		}
		if (selectedData.get("activity") == true) {
			this.b_activity.setVisible(true);
		}
		if (selectedData.get("illumination") == true) {
			this.b_illumination.setVisible(true);
		}
		if (selectedData.get("infrared") == true) {
			this.b_infrared.setVisible(true);
		}
		if (selectedData.get("infrared_and_visible") == true) {
			this.b_infrared_and_visible.setVisible(true);
		}
		if (selectedData.get("pressure") == true) {
			this.b_pressure.setVisible(true);
		}
		if (selectedData.get("humidity") == true) {
			this.b_humidity.setVisible(true);
		}
		if (selectedData.get("tvoc") == true) {
			this.b_tvoc.setVisible(true);
		}
		if (selectedData.get("temperature") == true) {
			this.b_temperature.setVisible(true);
		}
		
		
		if(this.isDataChoisi == true) {
			this.barchart.setVisible(true);
			this.barchartName.setVisible(true);
			this.dataPane.setVisible(true);
			//this.startTimer();
		} else {
			this.barchart.setVisible(false);
			this.barchartName.setVisible(false);
			this.dataPane.setVisible(false);
			this.derniereData.setText("");
		}
		this.alertPane.setVisible(true);
		this.b_configurer.setVisible(true);
		
		
	}
	
	/**
	 * Met à jour le graphe de donnée avec la date de la dernière donnée reçu et la valeur. 
	 * Sur la graphe, la donnée sera en rouge si elle n'est pas comprise entre les deux borne, sinon, elle sera en vert.
	 * 
	 * @param date la date de la donnée reçu
	 * @param valeur la valeur de la donnée reçu*
	 * @param seuilMin le seuil minimum
	 * @param seuilMax le seuil maximum 
	 */
	public void misteAJourBarChart(String date, int valeur, int seuilMin, int seuilMax){
		this.dataSerie.getData().add(new XYChart.Data<String, Number>(date, valeur));
		for(Data<String, Number> data : this.dataSerie.getData()) {
			if(data.getYValue().intValue()<seuilMin || data.getYValue().intValue()>seuilMax  ) {
				data.getNode().setStyle("-fx-bar-fill: firebrick;");
			} else {
				data.getNode().setStyle("-fx-bar-fill: #47b431;");
			}
        } 
		if(this.dataSerie.getData().size()>6) {
			this.dataSerie.getData().remove(0);
		}
		this.derniereData.setText("Date : "+date+" // Valeur  : "+valeur);
	}
	
	/**
	 * Rajoute la listes des différentes nouvelles alarmes à la list view des alarmes
	 * 
	 * @param newAlarmes la liste des nouvelles alarmes
	 */
	public void miseAJourListViewAlarmes(List<String> newAlarmes) {
		this.LV_alertes.getItems().addAll(newAlarmes);
		this.LV_alertes.scrollTo(this.LV_alertes.getItems().size());
	}

	/**
	 * Actualise l'affichage de la page (utilisé lorsque l'on modifier la configuration en pleine exécution).
	 */
	public void actualiserAffichageParametre() {
		this.seeContent();
		this.updateContent(this.barchartName.getText(), true, this.dataChoisi);
	}
	

	/**
	 * Permet d'appeler la fonction qui récupère toute les données présente dans le fichier de données d'une salle
	 * 
	 * @return une Liste de jsonObject des données
	 */
	public List<JsonObject> getAllData(){
		return this.nmf.doGetAllData(this.salleChoisi);
	}
	
	/**
	 * Permet d'appeler la fonction qui récupère les nouvelle données réçu dans le fichier de données d'une salle.
	 * 
	 * @return une Liste de jsonObject des nouvelles données. S'il n'y a pas de nouvelles données, la liste est vide.
	 */
	public List<JsonObject> getNewData(){
		return this.nmf.doGetNewData(this.salleChoisi);
	}
	
}
