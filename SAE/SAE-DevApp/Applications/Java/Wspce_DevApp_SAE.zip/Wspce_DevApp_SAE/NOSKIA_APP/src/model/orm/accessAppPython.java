package model.orm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;

import org.ini4j.Ini;
import org.ini4j.InvalidFileFormatException;

public class accessAppPython {
	
	private Process processPython;
	
	private Ini ini;

	private BufferedReader brAlarmesExpected;
	private List<String> expectedAlarmesRecord;
	
	private List<JsonObject> listeDesDonnees;
	private String deviceChoisi;
	
	
	/**
	 * Constructeur de la classe, permet d'initialiser l'attribut du fichier .ini, la liste des alertes que contient le fichier alarmes.txt et le bufferReader du fichier alarmes.txt.
	 * 
	 *
	 */
	public accessAppPython() {
		try {
			this.ini = new Ini(new File("src/model/data/config.ini"));
			this.brAlarmesExpected = new BufferedReader(new FileReader("src/model/data/alarmes.txt"));
			String currentLine ;
			this.expectedAlarmesRecord = new ArrayList<String>();
			while ((currentLine = this.brAlarmesExpected.readLine()) != null) {
				this.expectedAlarmesRecord.add(currentLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Lance l'application python sur un processus.
	 * 
	 * @return le processus sur lequel tourne le programme python
	 */
	public Process startPythonApp() {
		try {
			
			File f = new File("src/model/data/app.py");
			ProcessBuilder builder = new ProcessBuilder("python",f.getAbsolutePath());
			this.processPython = builder.start();
			
			/*
			//Récupération des affichages consoles du programme python (créer des beugs car nous avons une boucle infini dans le programme python)
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String lines = null;
			while((lines=reader.readLine())!=null) {
				System.out.println(lines);
			}*/
		} catch (IOException e) {

			e.printStackTrace();
		}
		return this.processPython;

	}

	/**
	 * Fini le processus sur lequel fonctionne l'application python
	 */
	public void stopPythonApp() {
		this.processPython.destroy();
	}
	
	/**
	 * Récupère les informations envoyé par la classe de gestion de la vue 
	 * et les enregistre dans le fichier config.ini de la partie model.
	 * 
	 * @param wantedData les données de la partie  "donnée récupérer" du formulaire (données que l'on veut afficher)
	 * @param seuils les données de la partie "seuils" du formulaire
	 * @param freq la fréquence à laquelle on récupère les données
	 * 
	 */
	public void saveConfiguration(Map<String, Boolean> wantedData, Map<String, String> seuils, String freq) {
		try {
			for(Entry<String, Boolean> e : wantedData.entrySet()) {
				this.ini.put("data",e.getKey(),e.getValue() );
			}
			
			for(Entry<String, String> e : seuils.entrySet()) {
				if(!e.getValue().equals("")) {
					this.ini.put("seuils",e.getKey(),e.getValue() );
				}
			}
			
			if(!freq.equals("")) {
				this.ini.put("frequences","freq-1",freq );
			}
			
			this.ini.store();
		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Récupère les valeurs de la partie "data" du fichier config.ini
	 * 
	 * Utilisé pour rechargé le paramétrage précédent des valeurs
	 * 
	 * @return HashMap la map des valeurs
	 */
	public Map<String, Boolean> getWantedData() {
		Map<String, Boolean> res = new HashMap<String, Boolean>();
		for(String key : this.ini.get("data").keySet()) {
			String value = this.ini.get("data", key);
			if(!key.equals("data_choisi")) {
				if(value.equals("true")) {
					res.put(key, true);
				} else {
					res.put(key, false);
				}
			}
		}
		return res;
	}
	
	/**
	 * Récupère les valeurs de la partie "seuils" du fichier config.ini
	 * 
	 * Utilisé pour rechargé le paramétrage précédent des valeurs
	 * 
	 * @return HashMap la map des valeurs
	 */
	public Map<String, String> getSeuils() {
		Map<String, String> res = new HashMap<String, String>();
		for(String key : this.ini.get("seuils").keySet()) {
			String value = this.ini.get("seuils", key);
			res.put(key, value);
		}
		return res;
	}
	
	/**
	 * Appelle la fonction qui récupère la de la partie "fréquences" du fichier config.ini
	 * 
	 * Utilisé pour rechagé le paramétrage précédent des valeurs
	 * 
	 * @return String la valeur en String (à convertir en float)
	 */
	public String getFrequence() {
		return this.ini.get("frequences", "freq-1");
	}
	
	
	/**
	 * Permet de modifier le champ "device_choisie" de la partie "device" du fichier .ini en enregistrant la salle choisi dans le menu déroulant
	 * Enregistre localement le nom du device en plus.
	 * 
	 * @param salle la salle du menu déroulant
	 */
	public void setDeviceChoisi(String salle) {
		this.ini.put("devices","device_choisi","${devices:device_salle_"+salle+"},");
		//this.ini.put("devices","device_choisi","${devices:all_device},");
		try {
			this.ini.store();
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.deviceChoisi = this.getDeviceNameBySalle(salle);
		this.listeDesDonnees = this.getData(this.deviceChoisi);
	}
	

	/**
	 * Permet d'appeler la fonction qui récupère toute les données présente dans le fichier de données d'une salle
	 * 
	 * @param salle la salle voulu
	 * @return une Liste de jsonObject des données triée en fonction de l'attribut date.
	 */
	public List<JsonObject> getData(String salle) {
		List<JsonObject> listeData = new ArrayList<JsonObject>();
		try (InputStream inputStream = new FileInputStream("src/model/data/data.json")) {
		    javax.json.JsonReader jsonReader = Json.createReader(inputStream);
		    JsonArray jsonArray = jsonReader.readArray();

		    jsonArray.forEach(jsonValue -> {
		        JsonObject jsonObject = jsonValue.asJsonObject();
		        if (jsonObject.getString("dev").equals(salle) && jsonObject.containsKey("dev")) {
		        	listeData.add(jsonObject.getJsonObject("val"));
			        }
		    });
		    jsonReader.close();
		    
		    listeData.sort(new Comparator<JsonObject>() {
		        @Override
		        public int compare(JsonObject o1, JsonObject o2) {
		            return o1.getString("date").compareTo(o2.getString("date"));
		        }
		    });
		}
		catch(IOException e) {
		    e.printStackTrace();
		}
		return listeData;
	}
	
	/**
	 * Récupère les nouvelle données réçu dans le fichier de données d'une salle.
	 * 
	 * @param salle la salle voulu
	 * @return une Liste de jsonObject des nouvelles données. S'il n'y a pas de nouvelles données, la liste est vide.
	 */
	public List<JsonObject> getNewData(String salle) {
		List<JsonObject> nvlListe = this.getData(salle);
		
		nvlListe.removeAll(this.listeDesDonnees);
		this.listeDesDonnees = this.getData(salle);
		return nvlListe;
	}
	

	/**
	 * Permet de récuperer les alertes de dépassement de seuils reçu
	 * 
	 * @return une List contenant toutes les nouvelles alertes depuis le derniers intervalle de temps.
	 */
	public List<String> getNewAlarm () {	
		List<String> newAlarmesRecord = new ArrayList<String>();

		try {
			@SuppressWarnings("resource")
			BufferedReader brAlarmesActual = new BufferedReader(new FileReader("src/model/data/alarmes.txt"));
			String currentLine;

			while((currentLine = brAlarmesActual.readLine()) != null) {
				if(!this.expectedAlarmesRecord.contains(currentLine)) {
					newAlarmesRecord.add(currentLine);
					this.expectedAlarmesRecord.add(currentLine);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return newAlarmesRecord;
	}
	
	/**
	 * Renvoie le nom du capteur en fonction de la salle
	 * 
	 * @param _salle la salle choisi
	 * @return son capteur attitré
	 */
	public String getDeviceNameBySalle(String _salle) {
		String device = null;
		switch (_salle) {
			case "B201" : 
				device = "AM107-2";
				break;
			case "B202" : 
				device = "AM107-3";
				break;
			case "B203" : 
				device = "AM107-4";
				break;
			case "B110" : 
				device = "AM107-5";
				break;
			case "B111" : 
				device = "AM107-6";
				break;
		}
		return device;
	}
	
	
}
